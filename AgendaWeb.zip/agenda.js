angular.module("agenda").controller("agendaCtrl", function($scope) {
    $scope.app = "Agenda de Contatos";
    $scope.contatos = [{
        nome: "Rafael", telefone: "48 98441-3119", idade: 28, dt_nasc: "27/06/1993",
        email: "rafael.r.mattos04@gmail.com" }
    ];
    $scope.adicionarContato = function (contato) {
        $scope.contatos.push(angular.copy(contato));
        delete $scope.contato;
        $scope.contatoForm.$setPristine();
    };
    $scope.apagarContatos = function (contatos){
        $scope.contatos = contatos.filter(function (contato){
            if (!contato.selecionado) return contato;
            $scope.contatoForm.$setPristine();
        });
    };
    $scope.isContatoSelecionado = function (contatos){
        return contatos.some(function (contato){
            return contato.selecionado;
        });
    };
    $scope.calcularIdade = function (dt_nasc){
        let diferenca = Math.abs(Date.now() - dt_nasc);
        let idade = Math.floor((diferenca / (1000 * 3600 * 24)) / 365.25);
        return idade;
    };
    $scope.salvarContato = function (contato) {
        localStorage.setItem("nome", contato.nome.value);
        localStorage.setItem("telefone", contato.telefone.value);
        localStorage.setItem("idade", contato.idade.value);
        localStorage.setItem("dt_nasc", contato.dt_nasc.value);
        localStorage.setItem("email", contato.email.value);
    }
});