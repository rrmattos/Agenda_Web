const Sequelize = require('sequelize');

const sequelize = new Sequelize('agenda', 'root', 'root', {
   host: 'localhost',
   dialect: 'mysql'
});

sequelize.authenticate().then(() => {
   console.log("Conexão realizada com sucesso!");
}).catch(() => {
   console.log("Erro: Não foi possível conectar na base.");
});

module.exports = sequelize;